<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
	<META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=utf-8">
	<TITLE></TITLE>
	<META NAME="GENERATOR" CONTENT="LibreOffice 4.1.6.2 (Linux)">
	<META NAME="AUTHOR" CONTENT="khalifa">
	<META NAME="CREATED" CONTENT="20160101;55400000000000">
	<META NAME="CHANGEDBY" CONTENT="Farid ahmed">
	<META NAME="CHANGED" CONTENT="20160101;55400000000000">
    <meta charset="UTF-8" />
	<STYLE TYPE="text/css">
	<!--
		@page { size: 8.5in 14in; margin-right: 0.5in; margin-top: 1in; margin-bottom: 0.5in }
		P { margin-bottom: 0.08in; direction: ltr; color: #000000; widows: 2; orphans: 2 }
		P.western { font-family: "Times New Roman", serif; font-size: 10pt; so-language: en-US }
		P.cjk { font-family: "Times New Roman", serif; font-size: 10pt }
		P.ctl { font-family: "Times New Roman", serif; font-size: 10pt; so-language: ar-SA }
.style1 {font-size: 16pt}
.style2 {
	font-size: 16;
	font-weight: bold;
}
	-->
	</STYLE>
</HEAD>
<BODY LANG="en-US" TEXT="#000000" DIR="LTR">
<TABLE WIDTH=685 CELLPADDING=7 CELLSPACING=0>
	<COL WIDTH=118>
	<COL WIDTH=406>
	<COL WIDTH=119>
	<TR>
		<TD WIDTH=113 HEIGHT=177 STYLE="border-top: 1.00pt solid #000000; border-bottom: 1.00pt solid #000000; border-left: 1.00pt solid #000000; border-right: none; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0in">
		  <P CLASS="western" ALIGN=CENTER><FONT FACE="SutonnyMJ"><FONT SIZE=3 STYLE="font-size: 13pt">wk¶v
			cÖwZôv‡bi mxj‡gvni</FONT></FONT></P>		</TD>
  <TD WIDTH=414 VALIGN=TOP STYLE="border-top: none; border-bottom: 1px solid #000000; border-left: 1.00pt solid #000000; border-right: none; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0in">
  <P ALIGN=center CLASS="western" STYLE="margin-bottom: 0in"><BR>
	  </P>
			<P ALIGN=center CLASS="western" STYLE="margin-bottom: 0in"><span class="western" style="margin-bottom: 0in"><span class="sd-abs-pos" style="position: absolute; top: 0in; left: 3.1in; width: 58px"><img src="assets/images/osadimg/i_32263abdbdb2a7b8_html_2c494fe7.png" name="Logo Karigory" width=58 height=48 border=0></span></span><BR>
	  </P>
			<P ALIGN=center CLASS="western" STYLE="margin-bottom: 0in"><FONT FACE="SutonnyMJ"><FONT SIZE=5 STYLE="font-size: 20pt"><B>evsjv‡`k
	  KvwiMwi wk¶v †evW©, XvKv</B></FONT></FONT></P>
			<p align="justify" class="western" style="margin-right: .1in; margin-bottom: 0in">
			  <FONT FACE="SutonnyMJ"><FONT SIZE=3><B>wW‡c&shy;&shy;vgv Bb
			    BwÄwbqvwis / wW‡c&shy;&shy;vgv Bb ‡U·UvBj BwÄwbqvwis I
			    Mv‡g©›Um wWRvBb GÛ c¨vUvb© †gwKs/wW‡c&shy;&shy;vgv Bb
			    GwMÖKvjPvi I wdmvwiR/ wW‡c&shy;&shy;vgv Bb ‡nj&amp;_
			    †UK‡bvjwR GÛ  mvwf©‡mm / wW‡c&shy;&shy;vgv Bb d‡iw÷ª
		      /wW‡c&shy;&shy;vgv Bb RyU †UK‡bvjwR wk¶vµg</B></FONT></FONT></p>
	  <P align="center" CLASS="western" STYLE="margin-bottom: 0in">              
			<SPAN class="style1" LANG="ar-SA"><span class="style2"><FONT FACE="Vrinda, sans-serif">ভর্তির</FONT>
	  <FONT FACE="Vrinda, sans-serif">আবেদনপত্র</FONT></span></SPAN></P>
			<P align="center" CLASS="western"><FONT FACE="SutonnyMJ"><FONT SIZE=4><B>		<?php print_r($acdSession[0][name]);?>
	  wk¶vel©</B></FONT></FONT></P>	  </TD>
  <TD WIDTH=114 STYLE="border: 1.00pt solid #000000; padding: 0in 0.08in">
	  <P CLASS="western" ALIGN=CENTER STYLE="margin-bottom: 0in"><FONT FACE="SutonnyMJ"><FONT SIZE=3 STYLE="font-size: 13pt">38wgt</FONT></FONT><FONT SIZE=3 STYLE="font-size: 13pt">×</FONT><FONT FACE="SutonnyMJ"><FONT SIZE=3 STYLE="font-size: 13pt">38wgt
			mvB‡Ri</FONT></FONT></P>
			<P CLASS="western" ALIGN=CENTER><FONT FACE="SutonnyMJ"><FONT SIZE=3 STYLE="font-size: 13pt">`yB
			Kwc Qwe</FONT></FONT></P>		</TD>
  </TR>
	<TR VALIGN=TOP>
		<TD WIDTH=113 height="93" STYLE="border-top: none; border-bottom: 1px solid #000000; border-left: none; border-right: none; padding: 0in">
		  <P CLASS="western"><BR>
	  </P>		</TD>
  <TD WIDTH=414 STYLE="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0in">
	  <P CLASS="western" STYLE="margin-bottom: 0in"> <FONT FACE="SutonnyMJ"><FONT SIZE=3>Awdm
			c~iY Ki‡e t</FONT></FONT></P>
			<P CLASS="western" STYLE="margin-bottom: 0in"> <FONT FACE="SutonnyMJ"><FONT SIZE=3>Av‡e`bc‡Îi
			µwgK bs
	  ......................<?php //echo $osadStudent[0][id];?>...........................</FONT></FONT></P>
			<P CLASS="western"> <FONT FACE="SutonnyMJ"><FONT SIZE=3>ZvwiL
	  ..........................<?php echo date('d/m/Y',strtotime($osadStudent[0][app_date]));?>..............................</FONT></FONT></P>		</TD>
  <TD WIDTH=114 STYLE="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0in">
  <P CLASS="western"><BR>
	  </P>		</TD>
  </TR>
</TABLE>
<P CLASS="western" STYLE="margin-bottom: 0in; line-height: 125%"><FONT FACE="SutonnyMJ"><FONT SIZE=3>Av‡e`bKvix
c‚iY Ki‡e t</FONT></FONT></P>
<TABLE WIDTH=684 CELLPADDING=7 CELLSPACING=0>
	<COLGROUP>
		<COL WIDTH=16>
		<COL WIDTH=106>
	</COLGROUP>
	<COLGROUP>
		<COL WIDTH=520>
	</COLGROUP>
	<TR VALIGN=TOP>
		<TD WIDTH=16 STYLE="border: none; padding: 0in">
			<P CLASS="western" STYLE="text-indent: -0.08in"><FONT FACE="SutonnyMJ"><FONT SIZE=3 STYLE="font-size: 13pt">1.</FONT></FONT></P>
		</TD>
		<TD ROWSPAN=2 WIDTH=106 STYLE="border: none; padding: 0in">
			<P CLASS="western" STYLE="margin-bottom: 0in"><FONT FACE="SutonnyMJ"><FONT SIZE=3 STYLE="font-size: 13pt">cÖv_©xi
			c~Y© bvg t </FONT></FONT>
			</P>
			<P CLASS="western"><FONT FACE="SutonnyMJ">(GmGmwm cix¶vi cÖ‡ekcÎ
			Abyhvqx)</FONT></P>
		</TD>
		<TD WIDTH=520 STYLE="border-top: none; border-bottom: none; border-left: 1.00pt solid #000000; border-right: none; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0in">
			<P CLASS="western" STYLE="margin-right: -0.01in"><FONT FACE="SutonnyMJ"><FONT SIZE=3 STYLE="font-size: 13pt">evsjvq
			t	</FONT></FONT><b><?php echo $osadStudent[0][name_bn];?></b></P>
		</TD>
	</TR>
	<TR>
		<TD WIDTH=16 VALIGN=TOP STYLE="border: none; padding: 0in">
			<P CLASS="western"><BR>
			</P>
		</TD>
		<TD WIDTH=520 VALIGN=TOP STYLE="border-top: none; border-bottom: none; border-left: 1.00pt solid #000000; border-right: none; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0in">
			<P CLASS="western" STYLE="margin-right: -0.01in"><FONT FACE="SutonnyMJ"><FONT SIZE=3 STYLE="font-size: 13pt">Bs‡iwR‡Z
			t	 </FONT></FONT><b><?php echo $osadStudent[0][name_en];?></b>
			</P>
		</TD>
	</TR>
</TABLE>
<P CLASS="western" STYLE="margin-bottom: 0in; line-height: 125%"><FONT SIZE=3>2<!--<IMG src="assets/images/osadimg/i_32263abdbdb2a7b8_html_fa3523c0.gif" ALIGN=LEFT HSPACE=12>--><FONT FACE="SutonnyMJ">.
	(K) wcZvi bvg</FONT>
.....<?php echo $osadStudent[0][father_name];?>.. <FONT FACE="SutonnyMJ">(M)
gyw³‡hv×vi mšÍvb/mšÍv‡bi mšÍvb t <?php if ($osadStudent[0][ff_son]){?><strong>n¨vu</strong> <?php }else {?><strong>bv</strong><?php } ?></FONT></FONT><span class="western" style="margin-bottom: 0in; line-height: 125%"><font face="SutonnyMJ"><font size=3><span class="western" style="margin-bottom: 0in; line-height: 125%"><font face="SutonnyMJ"><font size=3><!--<img src="assets/images/osadimg/i_32263abdbdb2a7b8_html_fa3523c0.gif" align=LEFT hspace=12>--></font></font></span></font></font></span></P>
<P CLASS="western" STYLE="margin-bottom: 0in; line-height: 125%"><FONT SIZE=3>	<!--<IMG src="assets/images/osadimg/i_32263abdbdb2a7b8_html_fa3523c0.gif" ALIGN=LEFT HSPACE=12>--><!--<IMG src="assets/images/osadimg/i_32263abdbdb2a7b8_html_fa3523c0.gif" ALIGN=LEFT HSPACE=12>--><FONT FACE="SutonnyMJ">(L)
gvZvi bvg
t......</FONT><?php echo $osadStudent[0][mother_name];?><FONT FACE="SutonnyMJ">
(N) DcRvwZ           t <?php if ($osadStudent[0][upjati]){?><strong>n¨vu</strong> <?php }else {?><strong>bv</strong><?php } ?></FONT></FONT><span class="western" style="margin-bottom: 0in; line-height: 125%"><font face="SutonnyMJ"><font size=3><span class="western" style="margin-bottom: 0in; line-height: 125%"><font face="SutonnyMJ"><font size=3><!--<img src="assets/images/osadimg/i_32263abdbdb2a7b8_html_fa3523c0.gif" align=LEFT hspace=12>--></font></font></span></font></font></span></FONT></FONT>
</P>
<P CLASS="western" STYLE="margin-bottom: 0in; line-height: 125%"><FONT FACE="SutonnyMJ"><FONT SIZE=3>3.
    Awffve‡Ki bvg (wcZvi
AeZ©gv‡b) t ....</FONT></FONT><?php echo $osadStudent[0][gardian_name];?>
</P>
<P CLASS="western" STYLE="margin-bottom: 0in; line-height: 125%"><FONT FACE="SutonnyMJ"><FONT SIZE=3>4.
	RvZxqZv t </FONT></FONT><strong><?php echo $osadStudent[0][nationality];?></strong><FONT FACE="SutonnyMJ"> 5. Rb¥ ZvwiL t
<strong><?php echo $osadStudent[0][birthday];?></strong>. 6. ag© t
....</FONT><strong><?php echo $osadStudent[0][religion];?></strong></FONT>
</P>
<P CLASS="western" STYLE="margin-bottom: 0in; line-height: 125%"><FONT FACE="SutonnyMJ"><FONT SIZE=3>7.
	¯’vqx wVKvbv t
......</FONT></FONT><strong><?php echo $osadStudent[0][pr_address];?></strong></P>
<P CLASS="western" STYLE="margin-bottom: 0in; line-height: 125%"><FONT FACE="SutonnyMJ"><FONT SIZE=3>8.	
‡hvMv‡hv‡Mi wVKvbv (†Uwj‡dvb/†gvevBj b¤^imn)t
....</FONT></FONT><strong><?php echo $osadStudent[0][cur_address];?>,Cell: <?php echo $osadStudent[0][phone];?></strong></P>
<P CLASS="western" STYLE="margin-bottom: 0in; line-height: 125%">    
   
<FONT FACE="SutonnyMJ"><FONT SIZE=3>................................................................................................................................................</FONT></FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0in; line-height: 125%"><FONT FACE="SutonnyMJ"><FONT SIZE=3>9.
	wk¶vMZ †hvM¨Zv t </FONT></FONT>
</P>
<TABLE WIDTH=649 CELLPADDING=7 CELLSPACING=0>
	<COL WIDTH=153>
	<COL WIDTH=52>
	<COL WIDTH=53>
	<COL WIDTH=57>
	<COL WIDTH=136>
	<COL WIDTH=112>
	<TR>
		<TD WIDTH=153 STYLE="border-top: 1.00pt solid #000000; border-bottom: 1.00pt solid #000000; border-left: 1.00pt solid #000000; border-right: none; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0in">
			<P CLASS="western" ALIGN=CENTER><FONT FACE="SutonnyMJ"><FONT SIZE=3>cix¶v</FONT></FONT></P>
		</TD>
		<TD WIDTH=52 STYLE="border-top: 1.00pt solid #000000; border-bottom: 1.00pt solid #000000; border-left: 1.00pt solid #000000; border-right: none; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0in">
			<P CLASS="western" ALIGN=CENTER><FONT FACE="SutonnyMJ"><FONT SIZE=3>MÖ“c/†UªW</FONT></FONT></P>
		</TD>
		<TD WIDTH=53 STYLE="border-top: 1.00pt solid #000000; border-bottom: 1.00pt solid #000000; border-left: 1.00pt solid #000000; border-right: none; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0in">
			<P CLASS="western" ALIGN=CENTER>†<FONT FACE="SutonnyMJ"><FONT SIZE=3>evW©</FONT></FONT></P>
		</TD>
		<TD WIDTH=57 STYLE="border-top: 1.00pt solid #000000; border-bottom: 1.00pt solid #000000; border-left: 1.00pt solid #000000; border-right: none; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0in">
			<P CLASS="western"><FONT FACE="SutonnyMJ"><FONT SIZE=3>cv‡mi mb</FONT></FONT></P>
		</TD>
		<TD WIDTH=136 STYLE="border-top: 1.00pt solid #000000; border-bottom: 1.00pt solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0in">
			<P CLASS="western" ALIGN=CENTER STYLE="margin-left: -0.08in; text-indent: 0.08in">
			<FONT FACE="SutonnyMJ"><FONT SIZE=3>mvaviY MwYZ/D”PZi MwYZ
			/weÁv‡b cÖvß wRwc/b¤^i (cÖ‡hvR¨ ‡¶‡Î)</FONT></FONT></P>
		</TD>
		<TD WIDTH=112 VALIGN=TOP STYLE="border: 1.00pt solid #000000; padding: 0in 0.08in">
			<P CLASS="western" ALIGN=CENTER>†<FONT FACE="SutonnyMJ"><FONT SIZE=3>gvU
			cÖvß wRwcG/b¤^i (cÖ‡hvR¨ †¶‡Î)</FONT></FONT></P>
		</TD>
	</TR>
    <?php foreach($osadacdhistory as $osadacdhistorys){
	
	// if($osadacdhistorys[osad_student_id]==$osadStudent[0][id]){
	 // print_r($osadacdhistorys);
 //}
	
	  ?>
	<TR VALIGN=TOP>
		<TD WIDTH=153 STYLE="border-top: 1.00pt solid #000000; border-bottom: 1.00pt solid #000000; border-left: 1.00pt solid #000000; border-right: none; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0in">
			<P CLASS="western" STYLE="margin-top: 0.01in"><?php echo $osadacdhistorys[examtype];?></FONT>
			</P>
		</TD>
		<TD WIDTH=52 STYLE="border-top: 1.00pt solid #000000; border-bottom: 1.00pt solid #000000; border-left: 1.00pt solid #000000; border-right: none; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0in">
			<P CLASS="western" STYLE="margin-top: 0.01in"><?php echo $osadacdhistorys[group];?><BR>
			</P>
		</TD>
		<TD WIDTH=53 STYLE="border-top: 1.00pt solid #000000; border-bottom: 1.00pt solid #000000; border-left: 1.00pt solid #000000; border-right: none; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0in">
			<P CLASS="western" STYLE="margin-top: 0.01in"><?php echo $osadacdhistorys[board];?><BR>
			</P>
		</TD>
		<TD WIDTH=57 STYLE="border-top: 1.00pt solid #000000; border-bottom: 1.00pt solid #000000; border-left: 1.00pt solid #000000; border-right: none; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0in">
			<P CLASS="western" STYLE="margin-top: 0.01in"><?php echo $osadacdhistorys[passing_yr];?><BR>
			</P>
		</TD>
		<TD WIDTH=136 STYLE="border-top: 1.00pt solid #000000; border-bottom: 1.00pt solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0in">
			<P CLASS="western" STYLE="margin-top: 0.01in"><?php echo $osadacdhistorys[special_mark];?><BR>
			</P>
		</TD>
		<TD WIDTH=112 STYLE="border: 1.00pt solid #000000; padding: 0in 0.08in">
			<P CLASS="western" STYLE="margin-top: 0.01in"><?php echo $osadacdhistorys[ttl_mark];?><BR>
			</P>
		</TD>
	</TR>
    <?php } ?>
	
</TABLE>
<P CLASS="western" STYLE="margin-bottom: 0in"><FONT FACE="SutonnyMJ"><FONT SIZE=3 STYLE="font-size: 13pt">10.
	K) </FONT></FONT><FONT FACE="SutonnyMJ"><FONT SIZE=2 STYLE="font-size: 11pt">†h
†UK‡bvjwR‡Z co‡Z BPQyK (cQ‡›`i µgvbymv‡i)</FONT></FONT><FONT FACE="SutonnyMJ"><FONT SIZE=3 STYLE="font-size: 13pt">
t        </FONT></FONT> <strong><?php echo $osadStudent[0][technology];?></strong></P>
<P CLASS="western" STYLE="margin-bottom: 0in"><FONT FACE="SutonnyMJ"><FONT SIZE=2 STYLE="font-size: 11pt">	(cÖwZôv‡b
Pvjy †UK‡bvjwR Abyhvqx) 	</FONT></FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0in"><FONT FACE="SutonnyMJ"><FONT SIZE=3 STYLE="font-size: 13pt">	L)
</FONT></FONT><FONT FACE="SutonnyMJ"><FONT SIZE=2 STYLE="font-size: 11pt"><B>‡U·UvB‡ji
†¶‡Ît</B></FONT></FONT><FONT FACE="SutonnyMJ"><FONT SIZE=2 STYLE="font-size: 11pt">
†h cÖwZôv‡b co‡Z B”QyK Zv cQ‡›`i</FONT></FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0in"><FONT FACE="SutonnyMJ"><FONT SIZE=3 STYLE="font-size: 13pt">	</FONT></FONT><FONT FACE="SutonnyMJ"><FONT SIZE=2 STYLE="font-size: 11pt">µgvbymv‡i
wjL‡Z n‡e| fwZ© cix¶vq</FONT></FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0in">       <FONT FACE="SutonnyMJ"><FONT SIZE=2 STYLE="font-size: 11pt">Ask
MÖnY B”QyK cÖwZôvb ‡K‡›`ªi bvg D‡j&shy;L Ki‡Z n‡e|</FONT></FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0in; line-height: 125%"><FONT FACE="SutonnyMJ"><FONT SIZE=3 STYLE="font-size: 13pt">11.
	UvKv cÖ`v‡bi iwm` b¤^i t ......................................
	ZvwiL .......................................................... </FONT></FONT>
</P>
<P CLASS="western" STYLE="margin-bottom: 0in"><FONT FACE="SutonnyMJ"><FONT SIZE=3 STYLE="font-size: 13pt">12.
	mshyw³ t 	</FONT></FONT><FONT FACE="SutonnyMJ"><FONT SIZE=2 STYLE="font-size: 11pt">(K)
GmGmwm (†fv‡Kkbvj)/GmGmwm(mvaviY)/`vwLj/mggvb cix¶vi
UªvÝwµÞ/b¤^ic‡Îi mZ¨vwqZ Kwc| </FONT></FONT>
</P>
<P CLASS="western" STYLE="margin-bottom: 0in"><FONT FACE="SutonnyMJ"><FONT SIZE=2 STYLE="font-size: 11pt">	(L)
me©‡kl †h wk¶v cÖwZôv‡b Aa¨qb K‡i‡Q/Ki‡Q †m
cÖwZôvb cÖav‡bi cÖksmvc‡Îi mZ¨vwqZ Kwc| </FONT></FONT>
</P>
<P CLASS="western" STYLE="margin-bottom: 0in"><FONT FACE="SutonnyMJ"><FONT SIZE=2 STYLE="font-size: 11pt">	(M)
†UªW cix¶v cv‡mi UªvÝwµÞ/b¤^ic‡Îi mZ¨vwqZ Kwc (cÖ‡qvR¨
†¶‡Î)| </FONT></FONT>
</P>
<P CLASS="western" STYLE="margin-bottom: 0in"><FONT FACE="SutonnyMJ"><FONT SIZE=2 STYLE="font-size: 11pt">	(N)
dig µq eve` b`M UvKv/†cv÷vj AW©vi cÖ`v‡bi iwm`| </FONT></FONT>
</P>
<P CLASS="western" STYLE="margin-bottom: 0in"><FONT FACE="SutonnyMJ"><FONT SIZE=2 STYLE="font-size: 11pt">	(O)
cvm‡cvU© AvKv‡ii `yB Kwc mZ¨vwqZ Qwe| </FONT></FONT>
</P>
<P CLASS="western" STYLE="margin-bottom: 0in">                       
   <FONT FACE="SutonnyMJ"><FONT SIZE=2 STYLE="font-size: 11pt">(P)
DcRvwZ/gyw³‡hv×vi mb` c‡Îi mZ¨vwqZ Kwc Ges </FONT></FONT><FONT FACE="SutonnyMJ"><FONT SIZE=2 STYLE="font-size: 11pt">gyw³‡hv×vi
†cvl¨ </FONT></FONT><FONT FACE="SutonnyMJ"><FONT SIZE=2 STYLE="font-size: 11pt">cÖgv‡bi
mb`|
</FONT></FONT><br /><br /><FONT FACE="SutonnyMJ"><FONT SIZE=3 STYLE="font-size: 13pt">.........................................................................................................................................................</FONT></FONT></P>
<P CLASS="western" ALIGN=CENTER STYLE="margin-bottom: 0in"><FONT FACE="SutonnyMJ"><FONT SIZE=5 STYLE="font-size: 17pt"><B>evsjv‡`k
KvwiMwi wk¶v †evW©, XvKv</B></FONT></FONT></P>
<P CLASS="western" STYLE="margin-right: -0.08in; margin-bottom: 0in"><FONT FACE="SutonnyMJ"><FONT SIZE=3><B>wW‡c&shy;&shy;vgv-Bb-BwÄwbqvwis
/ wW‡c&shy;&shy;vgv-Bb-‡U·UvBj BwÄwbqvwis I Mv‡g©›Um
wWRvBb GÛ c¨vUvb© †gwKs/ wW‡c&shy;&shy;vgv-Bb-GwMÖKvjPvi I
wdmvwiR/ wW‡c&shy;&shy;vgv-Bb-‡nj&amp;_ †UK‡bvjwR GÛ 
mvwf©‡mm / wW‡c&shy;&shy;vgv-Bb-d‡iw÷ª / wW‡c&shy;&shy;vgv-Bb-RyU
†UK‡bvjwR wk¶vµg</B></FONT></FONT></P>
<P CLASS="western" ALIGN=CENTER STYLE="margin-bottom: 0in"><FONT FACE="SutonnyMJ"><FONT SIZE=3 STYLE="font-size: 13pt"><B><?php print_r($acdSession[0][name]);?>  
wk¶vel©</B></FONT></FONT></P>
<TABLE WIDTH=678 CELLPADDING=7 CELLSPACING=0>
	<COL WIDTH=105>
	<COL WIDTH=544>
	<TR>
		<TD WIDTH=105 STYLE="border-top: 1.00pt solid #000000; border-bottom: 1.00pt solid #000000; border-left: 1.00pt solid #000000; border-right: none; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0in">
			<P CLASS="western" ALIGN=CENTER STYLE="margin-bottom: 0in"><FONT FACE="SutonnyMJ"><FONT SIZE=3>cÖwZôv‡bi
			mxj‡gvni</FONT></FONT></P>
			<P CLASS="western" ALIGN=CENTER STYLE="margin-bottom: 0in"><FONT FACE="SutonnyMJ"><FONT SIZE=3>I</FONT></FONT></P>
			<P CLASS="western" ALIGN=CENTER><FONT FACE="SutonnyMJ"><FONT SIZE=3>cÖwZôvb
			cÖav‡bi ¯^v¶i</FONT></FONT></P>
		</TD>
		<TD WIDTH=544 VALIGN=TOP STYLE="border-top: none; border-bottom: none; border-left: 1.00pt solid #000000; border-right: none; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0in">
			<P CLASS="western" STYLE="margin-bottom: 0in"><FONT FACE="SutonnyMJ"><FONT SIZE=3>cÖv_x©i
			bvg t 	</FONT></FONT><strong><?php echo $osadStudent[0][name_en];?></strong></P>
			<P CLASS="western" STYLE="margin-bottom: 0in"><FONT FACE="SutonnyMJ"><FONT SIZE=3>wcZvi
			bvg t 	</FONT></FONT><strong><?php echo $osadStudent[0][father_name];?></strong></P>
			<P CLASS="western" STYLE="margin-bottom: 0in"><FONT FACE="SutonnyMJ"><FONT SIZE=3>gvZvi
			bvg t 	</FONT></FONT><strong><?php echo $osadStudent[0][mother_name];?></strong></P>
			<P CLASS="western" STYLE="margin-bottom: 0in"><FONT FACE="SutonnyMJ"><FONT SIZE=3>Av‡e`bc‡Îi
			µwgK bs t
			...................<?php //echo $osadStudent[0][id];?>............... ZvwiL t	
			
			  <strong> <?php echo date('d/m/Y',strtotime($osadStudent[0][app_date]));?></strong></FONT></FONT></P>
			<P CLASS="western"><FONT FACE="SutonnyMJ"><FONT SIZE=3>UvKv
			cÖ`v‡bi iwm` bs t
			........................................................... ZvwiL
			t	</FONT></FONT></P>
		</TD>
	</TR>
</TABLE>
<P CLASS="western" ALIGN=CENTER STYLE="margin-bottom: 0in; line-height: 125%">
<BR>
</P>
<P CLASS="western" ALIGN=CENTER STYLE="margin-bottom: 0in; line-height: 125%;">
<FONT FACE="SutonnyMJ"><FONT SIZE=3 STYLE="font-size: 13pt">-2-</FONT></FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0in; line-height: 125%;"><FONT FACE="SutonnyMJ"><FONT SIZE=3 STYLE="font-size: 13pt"><B>13.	Av‡e`bKvixi
A½xKvibvgv t 	</B></FONT></FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0in; line-height: 125%"><BR>
</P>
<P CLASS="western" ALIGN=JUSTIFY STYLE="margin-left: 0.38in; margin-right: 0.4in; margin-bottom: 0in; line-height: 125%">
<FONT FACE="SutonnyMJ"><FONT SIZE=3 STYLE="font-size: 13pt">GB g‡g©
A½xKvi KiwQ †h, fwZ© nIqvi my‡hvM ‡c‡j Avwg AÎ wk¶v
cÖwZôvb  I evsjv‡`k KvwiMwi wk¶v †ev‡W©i hveZxq AvBbKvbyb
‡g‡b Pje Ges †Kvb Ae¯’v‡ZB AÎ wk¶v cÖwZôvb, evsjv‡`k
KvwiMwi wk¶v †evW© Ges †`‡ki AvB‡bi cwicwš’ †Kvb Kv‡R
wjß ne bv| </FONT></FONT>
</P>
<P CLASS="western" STYLE="margin-bottom: 0in; line-height: 125%"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0in; line-height: 125%"><IMG src="assets/images/osadimg/i_32263abdbdb2a7b8_html_6ec5a007.gif" ALIGN=LEFT HSPACE=12><IMG src="assets/images/osadimg/i_32263abdbdb2a7b8_html_be45ab68.gif" ALIGN=LEFT HSPACE=12><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0in; line-height: 125%">   
<FONT FACE="SutonnyMJ">
<FONT SIZE=3 STYLE="font-size: 13pt;border-top: 1pt solid #000000;">wcZv/gvZv/Awffve‡Ki
¯^v¶i I ZvwiL</FONT>
<FONT SIZE=3 STYLE="font-size: 13pt;border-top: 1pt solid #000000; margin-left:5in;">Av‡e`bKvixi ¯^v¶i I ZvwiL</FONT>
</FONT>
</P>
<P CLASS="western" STYLE="margin-bottom: 0in; line-height: 125%"><BR>
</P>
<!--<P CLASS="western" ALIGN=CENTER STYLE="margin-bottom: 0in; border-top: 1.50pt solid #000000; border-bottom: none; border-left: none; border-right: none; padding: 0in; line-height: 125%">
<BR>
</P>-->
<P CLASS="western" ALIGN=CENTER STYLE="margin-bottom: 0in; border-top: 1.50pt solid #000000; border-bottom: none; border-left: none; border-right: none; padding: 0in; line-height: 125%"><BR>
<FONT FACE="SutonnyMJ"><FONT SIZE=3 STYLE="font-size: 13pt">(wk¶v
cÖwZôvb KZ…©c‡¶i e¨env‡ii Rb¨)</FONT></FONT><BR></P><BR><BR>
<!--<P CLASS="western" ALIGN=CENTER STYLE="margin-bottom: 0in; border-top: 1.50pt solid #000000; border-bottom: none; border-left: none; border-right: none; padding: 0in; line-height: 125%">
<BR>
</P>-->
<!--<P CLASS="western" ALIGN=CENTER STYLE="margin-bottom: 0in; border-top: 1.50pt solid #000000; border-bottom: none; border-left: none; border-right: none; padding: 0in; line-height: 125%">
<BR>
</P>-->
<P CLASS="western" STYLE="margin-bottom: 0in; line-height: 125%"><FONT FACE="SutonnyMJ"><FONT SIZE=3 STYLE="font-size: 13pt">14.
(K) GmGmwm/mggv‡bi cix¶vq cÖvß b¤^i t ...................(L)
fwZ© cix¶vq cÖvß b¤^i t(miKvwi cÖwZôv‡bi Rb¨)............ .
</FONT></FONT>
</P>
<P CLASS="western" STYLE="margin-bottom: 0in; line-height: 125%"><FONT FACE="SutonnyMJ"><FONT SIZE=3 STYLE="font-size: 13pt">15.
Av‡e`bKvix KZ…©K fwZ©i Rb¨ cÖvß b¤^i(14 bs Gi K+L) t
........................†gavi µwgK t 	</FONT></FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0in; line-height: 125%"><FONT FACE="SutonnyMJ"><FONT SIZE=3 STYLE="font-size: 13pt">16.
AbygwZcÖvß †UK‡bvjwRi bvg
t........................................................... fwZ©i
AbygwZ †`qv nj|</FONT></FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0in; line-height: 125%"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0in; line-height: 125%"><IMG src="assets/images/osadimg/i_32263abdbdb2a7b8_html_eb135d15.gif" ALIGN=LEFT HSPACE=12><IMG src="assets/images/osadimg/i_32263abdbdb2a7b8_html_eb135d15.gif" ALIGN=LEFT HSPACE=12><IMG src="assets/images/osadimg/i_32263abdbdb2a7b8_html_eb135d15.gif" ALIGN=LEFT HSPACE=12><BR>
</P><br />
<P CLASS="western" STYLE="margin-bottom: 0in; line-height: 125%"><FONT FACE="SutonnyMJ">
<FONT SIZE=3 STYLE="font-size: 13pt; margin-left:0in;border-top: 1pt solid #000000;">‡iwR÷ªvi</FONT>
<FONT SIZE=3 STYLE="font-size: 13pt; margin-left:2.5in;border-top: 1pt solid #000000;">Dcva¨¶</FONT>
<FONT SIZE=3 STYLE="font-size: 13pt; margin-left:5in;border-top: 1pt solid #000000;">Aa¨¶</FONT>
</FONT>
</P>
<!--<P CLASS="western" STYLE="margin-bottom: 0in; line-height: 125%"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0in; line-height: 125%"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0in; line-height: 125%"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0in; line-height: 125%"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0in; line-height: 125%"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0in; line-height: 125%"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0in; line-height: 125%"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0in; line-height: 125%"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0in; line-height: 125%"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0in; line-height: 125%"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0in"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0in"><BR>
</P>-->
</BODY>
</HTML>